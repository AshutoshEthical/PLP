package com.cg.dao;

import java.sql.*;

import com.cg.exception.ICRException;
import com.cg.utiliy.JdbcUtility;

public class AdminDAO {
	
	static Connection connection = null;
	PreparedStatement statement = null;
	
	public static  String validate(String name, String pass) throws ICRException  {
		boolean status = false;
		String roleCode ="";
		try {
			connection = JdbcUtility.getConnection();
			PreparedStatement ps = connection.prepareStatement("select rolecode from userrole where username=? and pwd=?");
			ps.setString(1, name);
			ps.setString(2, pass);

			ResultSet rs = ps.executeQuery();
			
			if(rs.next())
				roleCode = rs.getString(1);
		} catch (ICRException | SQLException e) {
			throw new ICRException(e.getMessage()+"Problem Occured in AdminDAO during login");
		}
		return roleCode;
	}
//	public static String getRoleCode(String userName) {
//		String roleCode = "";
//		try {
//			connection = JdbcUtility.getConnection();
//			Statement smt=connection.createStatement();
//			String query = "select rolecode from userrole where username="+userName;
//			ResultSet rs=smt.executeQuery(query);
//			roleCode = rs.getString(1);
//			System.out.println("rc"+roleCode);
//		} catch (Exception e) {
//			System.out.println(e.getMessage());
//		}
//		return roleCode;
//	}
	
}