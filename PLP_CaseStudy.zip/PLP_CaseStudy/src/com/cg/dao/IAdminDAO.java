package com.cg.dao;

import com.cg.exception.ICRException;

public interface IAdminDAO {

	int addAdmin(String username, String password, String rolecode) throws ICRException;

}
