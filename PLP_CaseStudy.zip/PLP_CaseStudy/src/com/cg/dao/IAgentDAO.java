package com.cg.dao;

import com.cg.exception.ICRException;

public interface IAgentDAO {

	public int addAgent(String userName, String password, String rollCode) throws ICRException;
}
